package aula.trabalho;

public class Main { 

     public static void main(String[] args) 
     { 

        TelaPrincipal tela = new TelaPrincipal(); 

    }     
} 
