package aula.trabalho;

import java.awt.Color;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfJurosComposto
{ 
    JFrame tela; 
    JLabel lbValorFuturo, lbCapital, lbResultado, lbMontante, lbPorcento, lbReais; 
    JTextField tfValorFuturo, tfCapital; 
    JButton btCalcular, btLimpar; 

    public TfJurosComposto() 
    { 
       
        tela = new JFrame("Cálculo do Juros Composto"); 
        lbValorFuturo = new JLabel("Montante: ");
        lbReais = new JLabel("Reais");
        lbCapital = new JLabel("Capital ");
        lbPorcento = new JLabel("Reais"); 
        lbMontante = new JLabel("Valor do Juros: "); 
        lbResultado = new JLabel("Resultado da Operação"); 
        tfValorFuturo= new JTextField(); 
        tfCapital = new JTextField(); 
        btCalcular = new JButton("Calcular"); 
        btLimpar = new JButton("Limpar");

        lbValorFuturo.setBounds(10, 10, 150, 20); 
        lbReais.setBounds(325, 10, 100, 20);
        lbCapital.setBounds(10, 35, 100, 20);
        lbPorcento.setBounds(325, 35, 100, 20);
        lbMontante.setBounds(10, 95, 100, 20); 
        lbResultado.setBounds(170, 95, 149, 20); 
        tfValorFuturo.setBounds(170, 10, 150, 20); 
        tfCapital.setBounds(170, 35, 150, 20);
        btCalcular.setBounds(10, 128, 265, 30); 
        btLimpar.setBounds(281, 128, 82, 30);
        
        lbResultado.setHorizontalAlignment(JLabel.CENTER);
        lbResultado.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbResultado.setOpaque(true); 

        btCalcular.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    Double jurosComposto, montante, capital; 
                    montante = Double.parseDouble(tfValorFuturo.getText()); 
                    capital = Double.parseDouble(tfCapital.getText()); 
                    jurosComposto = montante - capital;
                    lbResultado.setText(String.valueOf(jurosComposto) + " Reais"); 

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível realizar o cálculo."); 
                } 
            } 
        }); 
        
        btLimpar.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    tfValorFuturo.setText("");
                    tfCapital.setText("");
                    lbResultado.setText("Resultado da Operação");

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível limpar!"); 
                } 
            } 
        }); 
        
        tela.add(lbValorFuturo); 
        tela.add(lbCapital); 
        tela.add(lbResultado); 
        tela.add(tfValorFuturo); 
        tela.add(tfCapital);
        tela.add(btCalcular); 
        tela.add(lbMontante);
        tela.add(lbPorcento);
        tela.add(lbReais);
        tela.add(btLimpar);
  
        tela.setSize(390, 230); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
} 