package aula.trabalho;

import java.awt.Color;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfMontanteComposto 
{ 
    JFrame tela; 
    JLabel lbPrincipal, lbTaxaFixa, lbPeriodos, lbResultado, lbMontante, lbPorcento, lbReais, lbMes; 
    JTextField tfPrincipal, tfTaxaFixa, tfPeriodos; 
    JButton btCalcular, btLimpar; 

    public TfMontanteComposto () 
    { 
        
        tela = new JFrame("Cálculo do Montante"); 
        lbPrincipal = new JLabel("Valor Presente: ");
        lbReais = new JLabel("Reais");
        lbTaxaFixa = new JLabel("Taxa Fixa: ");
        lbPorcento = new JLabel("%"); 
        lbPeriodos = new JLabel("Quantidade de Periodos: "); 
        lbMes = new JLabel ("Meses");
        lbMontante = new JLabel("Montante: "); 
        lbResultado = new JLabel("Resultado da Operação"); 
        tfPrincipal= new JTextField(); 
        tfTaxaFixa = new JTextField(); 
        tfPeriodos = new JTextField();
        btCalcular = new JButton("Calcular"); 
        btLimpar = new JButton("Limpar");

        lbPrincipal.setBounds(10, 10, 150, 20); 
        lbReais.setBounds(325, 10, 100, 20);
        lbTaxaFixa.setBounds(10, 35, 100, 20);
        lbPorcento.setBounds(325, 35, 100, 20);
        lbPeriodos.setBounds(10, 60, 150, 20); 
        lbMes.setBounds(325, 60, 100, 20);
        lbMontante.setBounds(10, 95, 100, 20); 
        lbResultado.setBounds(170, 95, 149, 20); 
        tfPrincipal.setBounds(170, 10, 150, 20); 
        tfTaxaFixa.setBounds(170, 35, 150, 20);
        tfPeriodos.setBounds(170, 60, 150, 20);
        btCalcular.setBounds(10, 128, 265, 30); 
        btLimpar.setBounds(281, 128, 82, 30);
        
        lbResultado.setHorizontalAlignment(JLabel.CENTER);
        lbResultado.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbResultado.setOpaque(true); 

        btCalcular.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    Double principal, taxaFixa, periodos, montante; 
                    principal = Double.parseDouble(tfPrincipal.getText()); 
                    taxaFixa = Double.parseDouble(tfTaxaFixa.getText()); 
                    periodos = Double.parseDouble(tfPeriodos.getText()); 
                    taxaFixa = taxaFixa / 100;
                    montante = principal * Math.pow((1 + taxaFixa),periodos); //M = C (1+i)^ t
                    lbResultado.setText(String.valueOf(montante) + " Reais"); 

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível realizar o cálculo."); 
                } 
            } 
        }); 
        
        btLimpar.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    tfPrincipal.setText("");
                    tfTaxaFixa.setText("");
                    tfPeriodos.setText(""); 
                    lbResultado.setText("Resultado da Operação");

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível limpar!"); 
                } 
            } 
        }); 
        
        tela.add(lbPrincipal); 
        tela.add(lbTaxaFixa); 
        tela.add(lbPeriodos); 
        tela.add(lbResultado); 
        tela.add(tfPrincipal); 
        tela.add(tfTaxaFixa);
        tela.add(tfPeriodos);
        tela.add(btCalcular); 
        tela.add(lbMontante);
        tela.add(lbPorcento);
        tela.add(lbReais);
        tela.add(lbMes);
        tela.add(btLimpar);
  
        tela.setSize(390, 230); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
} 