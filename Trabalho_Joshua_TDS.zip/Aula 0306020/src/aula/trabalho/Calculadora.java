package aula.trabalho;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class Calculadora extends javax.swing.JFrame {

    public float primeiroNumero;
    public float segundoNumero;
    public String operador;
    
    URL url = this.getClass().getResource("logoCalc.png");
    Image imagemTitulo = Toolkit.getDefaultToolkit().getImage(url);
 
    
    public Calculadora() {
        
        initComponents();
        this.setLocationRelativeTo(null);
        this.setIconImage(imagemTitulo);
        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtOperacao2 = new javax.swing.JLabel();
        lbResultado = new javax.swing.JLabel();
        jButtonMud = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButtonP = new javax.swing.JButton();
        jButtonC = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButtonD = new javax.swing.JButton();
        jButtonMu = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButtonMe = new javax.swing.JButton();
        jButtonI = new javax.swing.JButton();
        jButtonMa = new javax.swing.JButton();
        jButton0 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(300, 530));
        setPreferredSize(new java.awt.Dimension(300, 530));
        setResizable(false);
        setSize(new java.awt.Dimension(300, 530));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowDeactivated(java.awt.event.WindowEvent evt) {
                formWindowDeactivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(244, 253, 251));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtOperacao2.setFont(new java.awt.Font("Courier New", 1, 18)); // NOI18N
        txtOperacao2.setForeground(new java.awt.Color(51, 58, 67));
        txtOperacao2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(txtOperacao2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 260, -1));

        lbResultado.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 48)); // NOI18N
        lbResultado.setForeground(new java.awt.Color(51, 58, 67));
        lbResultado.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(lbResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 73, 270, -1));

        jButtonMud.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/mudarCor1.png"))); // NOI18N
        jButtonMud.setBorderPainted(false);
        jButtonMud.setContentAreaFilled(false);
        jButtonMud.setFocusPainted(false);
        jButtonMud.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/mudarCor2.png"))); // NOI18N
        jButtonMud.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/mudarCor2.png"))); // NOI18N
        jButtonMud.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMudActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonMud, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 130));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButtonP.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButtonP.setForeground(new java.awt.Color(51, 58, 67));
        jButtonP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButtonP.setText(".");
        jButtonP.setBorderPainted(false);
        jButtonP.setContentAreaFilled(false);
        jButtonP.setFocusPainted(false);
        jButtonP.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonP.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButtonP.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButtonP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonP, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 57, 57));

        jButtonC.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButtonC.setForeground(new java.awt.Color(51, 58, 67));
        jButtonC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonC.setText("C");
        jButtonC.setBorderPainted(false);
        jButtonC.setContentAreaFilled(false);
        jButtonC.setFocusPainted(false);
        jButtonC.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonC.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonC.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButtonC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonC, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, 57, 57));

        jButton7.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton7.setForeground(new java.awt.Color(51, 58, 67));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton7.setText("7");
        jButton7.setBorderPainted(false);
        jButton7.setContentAreaFilled(false);
        jButton7.setFocusPainted(false);
        jButton7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton7.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton7.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 57, 57));

        jButton4.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton4.setForeground(new java.awt.Color(51, 58, 67));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton4.setText("4");
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setFocusPainted(false);
        jButton4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton4.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton4.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 57, 57));

        jButton1.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 58, 67));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton1.setText("1");
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setFocusPainted(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton1.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 57, 57));

        jButton2.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 58, 67));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton2.setText("2");
        jButton2.setBorderPainted(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setFocusPainted(false);
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton2.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 57, 57));

        jButton5.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton5.setForeground(new java.awt.Color(51, 58, 67));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton5.setText("5");
        jButton5.setBorderPainted(false);
        jButton5.setContentAreaFilled(false);
        jButton5.setFocusPainted(false);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton5.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton5.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 150, 57, 57));

        jButton8.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton8.setForeground(new java.awt.Color(51, 58, 67));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton8.setText("8");
        jButton8.setBorderPainted(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setFocusPainted(false);
        jButton8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton8.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton8.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, 57, 57));

        jButtonD.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButtonD.setForeground(new java.awt.Color(51, 58, 67));
        jButtonD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonD.setText("/");
        jButtonD.setBorderPainted(false);
        jButtonD.setContentAreaFilled(false);
        jButtonD.setFocusPainted(false);
        jButtonD.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonD.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonD.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButtonD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonD, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 57, 57));

        jButtonMu.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButtonMu.setForeground(new java.awt.Color(51, 58, 67));
        jButtonMu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonMu.setText("*");
        jButtonMu.setBorderPainted(false);
        jButtonMu.setContentAreaFilled(false);
        jButtonMu.setFocusPainted(false);
        jButtonMu.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonMu.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonMu.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButtonMu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMuActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonMu, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 57, 57));

        jButton9.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton9.setForeground(new java.awt.Color(51, 58, 67));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton9.setText("9");
        jButton9.setBorderPainted(false);
        jButton9.setContentAreaFilled(false);
        jButton9.setFocusPainted(false);
        jButton9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton9.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton9.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 57, 57));

        jButton6.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton6.setForeground(new java.awt.Color(51, 58, 67));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton6.setText("6");
        jButton6.setBorderPainted(false);
        jButton6.setContentAreaFilled(false);
        jButton6.setFocusPainted(false);
        jButton6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton6.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton6.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 57, 57));

        jButton3.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton3.setForeground(new java.awt.Color(51, 58, 67));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton3.setText("3");
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setFocusPainted(false);
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt3.png"))); // NOI18N
        jButton3.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 57, 57));

        jButtonMe.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButtonMe.setForeground(new java.awt.Color(51, 58, 67));
        jButtonMe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonMe.setText("-");
        jButtonMe.setBorderPainted(false);
        jButtonMe.setContentAreaFilled(false);
        jButtonMe.setFocusPainted(false);
        jButtonMe.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonMe.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt1.png"))); // NOI18N
        jButtonMe.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/bt2.png"))); // NOI18N
        jButtonMe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMeActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonMe, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, 57, 57));

        jButtonI.setFont(new java.awt.Font("Dubai Light", 0, 32)); // NOI18N
        jButtonI.setForeground(new java.awt.Color(255, 255, 255));
        jButtonI.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btIgual.png"))); // NOI18N
        jButtonI.setText("=");
        jButtonI.setBorderPainted(false);
        jButtonI.setContentAreaFilled(false);
        jButtonI.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonI.setMaximumSize(new java.awt.Dimension(73, 25));
        jButtonI.setMinimumSize(new java.awt.Dimension(73, 25));
        jButtonI.setPreferredSize(new java.awt.Dimension(73, 25));
        jButtonI.setRequestFocusEnabled(false);
        jButtonI.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btGrande2.png"))); // NOI18N
        jButtonI.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btIgual.png"))); // NOI18N
        jButtonI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonIActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonI, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 220, 57, 120));

        jButtonMa.setFont(new java.awt.Font("Dubai Light", 0, 32)); // NOI18N
        jButtonMa.setForeground(new java.awt.Color(51, 58, 67));
        jButtonMa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btGrande1.png"))); // NOI18N
        jButtonMa.setText("+");
        jButtonMa.setBorderPainted(false);
        jButtonMa.setContentAreaFilled(false);
        jButtonMa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButtonMa.setMaximumSize(new java.awt.Dimension(73, 25));
        jButtonMa.setMinimumSize(new java.awt.Dimension(73, 25));
        jButtonMa.setPreferredSize(new java.awt.Dimension(73, 25));
        jButtonMa.setRequestFocusEnabled(false);
        jButtonMa.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btGrande2.png"))); // NOI18N
        jButtonMa.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btGrande1.png"))); // NOI18N
        jButtonMa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMaActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonMa, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 80, 57, 120));

        jButton0.setFont(new java.awt.Font("Dubai Light", 0, 28)); // NOI18N
        jButton0.setForeground(new java.awt.Color(51, 58, 67));
        jButton0.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btDeit3.png"))); // NOI18N
        jButton0.setText("0");
        jButton0.setBorderPainted(false);
        jButton0.setContentAreaFilled(false);
        jButton0.setFocusPainted(false);
        jButton0.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton0.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btDeit3.png"))); // NOI18N
        jButton0.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btDeit2.png"))); // NOI18N
        jButton0.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/btDeit1.png"))); // NOI18N
        jButton0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton0ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton0, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 110, 57));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 290, 370));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPActionPerformed
        if(!(this.lbResultado.getText().contains(".")))
        {
            this.lbResultado.setText(this.lbResultado.getText()+".");
            this.txtOperacao2.setText(this.txtOperacao2.getText()+".");

        }
    }//GEN-LAST:event_jButtonPActionPerformed

    private void jButtonCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCActionPerformed
        this.lbResultado.setText("");
        this.txtOperacao2.setText("");
        lbResultado.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        this.primeiroNumero = 0;
        this.segundoNumero = 0;
        lbResultado.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 48));
        
    }//GEN-LAST:event_jButtonCActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"7");
        this.lbResultado.setText(this.lbResultado.getText()+"7");
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"4");
        this.lbResultado.setText(this.lbResultado.getText()+"4");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"1");
        this.lbResultado.setText(this.lbResultado.getText()+"1");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"2");
        this.lbResultado.setText(this.lbResultado.getText()+"2");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"5");
        this.lbResultado.setText(this.lbResultado.getText()+"5");
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"8");
        this.lbResultado.setText(this.lbResultado.getText()+"8");
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButtonDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDActionPerformed
        try { this.primeiroNumero = Float.parseFloat(this.lbResultado.getText());
            this.operador = "/";
            this.lbResultado.setText("");
            this.txtOperacao2.setText(this.txtOperacao2.getText()+"/");
        } catch(Exception ex)
        {
            JOptionPane.showMessageDialog(lbResultado, "Erro!");
        }
    }//GEN-LAST:event_jButtonDActionPerformed

    private void jButtonMuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMuActionPerformed
        try { this.primeiroNumero = Float.parseFloat(this.lbResultado.getText());
            this.operador = "*";
            this.lbResultado.setText("");
            this.txtOperacao2.setText(this.txtOperacao2.getText()+"*");
        } catch(Exception ex)
        {
            JOptionPane.showMessageDialog(lbResultado, "Erro!");
        }
    }//GEN-LAST:event_jButtonMuActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"9");
        this.lbResultado.setText(this.lbResultado.getText()+"9");
        
        
        
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"6");
        this.lbResultado.setText(this.lbResultado.getText()+"6");
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"3");
        this.lbResultado.setText(this.lbResultado.getText()+"3");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButtonMeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMeActionPerformed
        try { this.primeiroNumero = Float.parseFloat(this.lbResultado.getText());
            this.operador = "-";
            this.lbResultado.setText("");
            this.txtOperacao2.setText(this.txtOperacao2.getText()+"-");
        } catch(Exception ex)
        {
            JOptionPane.showMessageDialog(lbResultado, "Erro!");
        }
    }//GEN-LAST:event_jButtonMeActionPerformed

    private void jButtonIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonIActionPerformed
        try{ this.segundoNumero = Float.parseFloat(this.lbResultado.getText());

            switch(this.operador)
            {
                case "+":this.lbResultado.setText(resul(this.primeiroNumero + this.segundoNumero));
                break;
                case "-":this.lbResultado.setText(resul(this.primeiroNumero - this.segundoNumero));
                break;
                case "*":this.lbResultado.setText(resul(this.primeiroNumero * this.segundoNumero));
                break;
                case "/":if(this.segundoNumero == 0)
                {
                    this.lbResultado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                    lbResultado.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 24));
                    this.lbResultado.setText("Não se pode dividir por 0!");

                } else {
                    this.lbResultado.setText(resul(this.primeiroNumero / this.segundoNumero));
                }
                break;
            }
        } catch(Exception ex)
        {
            JOptionPane.showMessageDialog(lbResultado, "Erro!");
        }
    }//GEN-LAST:event_jButtonIActionPerformed

    private void jButtonMaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMaActionPerformed
        try { this.primeiroNumero = Float.parseFloat(this.lbResultado.getText());
            this.operador = "+";
            this.txtOperacao2.setText(this.txtOperacao2.getText()+"+");
            this.lbResultado.setText("");
        } catch(Exception ex)
        {
            JOptionPane.showMessageDialog(lbResultado, "Erro!");
        }
    }//GEN-LAST:event_jButtonMaActionPerformed

    public void Registro (String digito){
        txtOperacao2.setText(txtOperacao2.getText() + digito);
    }
    
    private void jButton0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton0ActionPerformed
        this.txtOperacao2.setText(this.txtOperacao2.getText()+"0");
        this.lbResultado.setText(this.lbResultado.getText()+"0");
    }//GEN-LAST:event_jButton0ActionPerformed

    boolean modoEscuro = false;
    
    private void jButtonMudActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMudActionPerformed
        if(!modoEscuro)
        {
        jPanel1.setBackground(Color.decode("#212b41"));
        jPanel4.setBackground(Color.decode("#2e3951"));
        
        jButtonMud.setIcon(new ImageIcon(getClass().getResource("/imagens/mudarCor2.png")));
        
        mudarBotaoEscuro1(jButton0);
        mudarBotaoEscuro1(jButton1);
        mudarBotaoEscuro1(jButton2);
        mudarBotaoEscuro1(jButton3);
        mudarBotaoEscuro1(jButton4);
        mudarBotaoEscuro1(jButton5);
        mudarBotaoEscuro1(jButton6);
        mudarBotaoEscuro1(jButton7);
        mudarBotaoEscuro1(jButton8);
        mudarBotaoEscuro1(jButton9);
        mudarBotaoEscuro1(jButtonP);
        
        mudarBotaoEscuro2(jButtonC);
        mudarBotaoEscuro2(jButtonD);
        mudarBotaoEscuro2(jButtonMu);
        mudarBotaoEscuro2(jButtonMe);
        
        jButtonMa.setIcon(new ImageIcon(getClass().getResource("/imagens/btGrandeEs.png")));
        jButtonMa.setForeground(Color.decode("#0db689"));
        
        jButtonI.setForeground(Color.decode("#2d3850"));
        lbResultado.setForeground(Color.decode("#0db689"));
        txtOperacao2.setForeground(Color.decode("#0db689"));
        
        modoEscuro = true;
                
        } else 
            {
                jButtonMud.setIcon(new ImageIcon(getClass().getResource("/imagens/mudarCor1.png")));
                jPanel1.setBackground(Color.decode("#f4fdfb"));
                jPanel4.setBackground(Color.decode("#ffffff"));
        
                mudarBotaoClaro1(jButton0);
                mudarBotaoClaro1(jButton1);
                mudarBotaoClaro1(jButton2);
                mudarBotaoClaro1(jButton3);
                mudarBotaoClaro1(jButton4);
                mudarBotaoClaro1(jButton5);
                mudarBotaoClaro1(jButton6);
                mudarBotaoClaro1(jButton7);
                mudarBotaoClaro1(jButton8);
                mudarBotaoClaro1(jButton9);
                mudarBotaoClaro1(jButtonP);
        
                mudarBotaoClaro2(jButtonC);
                mudarBotaoClaro2(jButtonD);
                mudarBotaoClaro2(jButtonMu);
                mudarBotaoClaro2(jButtonMe);
        
                jButtonMa.setIcon(new ImageIcon(getClass().getResource("/imagens/btGrande1.png")));
                jButtonMa.setForeground(Color.decode("#6b7278"));
        
                jButtonI.setForeground(Color.decode("#f4fdfb"));
                lbResultado.setForeground(Color.decode("#323942"));
                txtOperacao2.setForeground(Color.decode("#323942"));  
                
                modoEscuro = false;
            }
    }//GEN-LAST:event_jButtonMudActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosing

    private void formWindowDeactivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowDeactivated
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowDeactivated

      public void mudarBotaoEscuro1(JButton botao)
      {
          botao.setIcon(new ImageIcon(getClass().getResource("/imagens/btEs1.png")));
          botao.setForeground(Color.decode("#464d55"));             
      }
      
      public void mudarBotaoEscuro2(JButton botao)
      {
          botao.setIcon(new ImageIcon(getClass().getResource("/imagens/btEs2.png")));
          botao.setForeground(Color.decode("#464d55"));             
      }
      
      public void mudarBotaoClaro1(JButton botao)
      {
          botao.setIcon(new ImageIcon(getClass().getResource("/imagens/bt3.png")));
          botao.setForeground(Color.decode("#505d6b"));             
      }
      
      public void mudarBotaoClaro2(JButton botao)
      {
          botao.setIcon(new ImageIcon(getClass().getResource("/imagens/bt1.png")));
          botao.setForeground(Color.decode("#505d6b"));             
      }
    
      public String resul (float resultado)
      {
          String retorno;
          
          retorno = "";
          
          retorno = Float.toString(resultado);
          
          if(resultado%1==0)
          {
              retorno = retorno.substring(0, retorno.length() - 2);   
          }
          
          return retorno;
      }    
    
    
            
       
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton0;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jButtonC;
    private javax.swing.JButton jButtonD;
    private javax.swing.JButton jButtonI;
    private javax.swing.JButton jButtonMa;
    private javax.swing.JButton jButtonMe;
    private javax.swing.JButton jButtonMu;
    private javax.swing.JButton jButtonMud;
    private javax.swing.JButton jButtonP;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel lbResultado;
    public javax.swing.JLabel txtOperacao2;
    // End of variables declaration//GEN-END:variables
}
