package aula.trabalho;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.net.URL;
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfDefiniCapital
{ 
    JFrame tela; 
    JLabel lbPrincipal, lbTaxaJuros, lbPeriodos, lbResultado, lbMontante, lbPorcento, lbReais, lbMes; 
    JTextField tfPrincipal, tfTaxaJuros, tfPeriodos; 
    JButton btCalcular, btLimpar; 
    
    public TfDefiniCapital() 
    { 

        tela = new JFrame("Cálculo do Capital"); 
        lbPrincipal = new JLabel("Valor Futuro: ");
        lbReais = new JLabel("Reais");
        lbTaxaJuros = new JLabel("Taxa de Juros: ");
        lbPorcento = new JLabel("%"); 
        lbPeriodos = new JLabel("Quantidade de Periodos: "); 
        lbMes = new JLabel ("Meses");
        lbMontante = new JLabel("Capital: "); 
        lbResultado = new JLabel("Resultado da Operação"); 
        tfPrincipal= new JTextField(); 
        tfTaxaJuros = new JTextField(); 
        tfPeriodos = new JTextField();
        btCalcular = new JButton("Calcular"); 
        btLimpar = new JButton("Limpar");

        lbPrincipal.setBounds(10, 10, 150, 20); 
        lbReais.setBounds(325, 10, 100, 20);
        lbTaxaJuros.setBounds(10, 35, 100, 20);
        lbPorcento.setBounds(325, 35, 100, 20);
        lbPeriodos.setBounds(10, 60, 150, 20); 
        lbMes.setBounds(325, 60, 100, 20);
        lbMontante.setBounds(10, 95, 100, 20); 
        lbResultado.setBounds(170, 95, 149, 20); 
        tfPrincipal.setBounds(170, 10, 150, 20); 
        tfTaxaJuros.setBounds(170, 35, 150, 20);
        tfPeriodos.setBounds(170, 60, 150, 20);
        btCalcular.setBounds(10, 128, 265, 30); 
        btLimpar.setBounds(281, 128, 82, 30);
        
        lbResultado.setHorizontalAlignment(JLabel.CENTER);
        lbResultado.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbResultado.setOpaque(true); 

        btCalcular.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    Double principal, taxaJuros, periodos;
                    Double montante;
                    montante = Double.parseDouble(tfPrincipal.getText()); 
                    taxaJuros = Double.parseDouble(tfTaxaJuros.getText()); 
                    periodos = Double.parseDouble(tfPeriodos.getText()); 
                    principal = montante / (1 + taxaJuros / 100 * periodos); //F = P.(1 + i.n)
                    lbResultado.setText(String.valueOf(principal) + " Reais"); 

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível realizar o cálculo."); 
                } 
            } 
            
        }); 
        
        btLimpar.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    tfPrincipal.setText("");
                    tfTaxaJuros.setText("");
                    tfPeriodos.setText(""); 
                    lbResultado.setText("Resultado da Operação");

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível limpar!"); 
                } 
            } 
        }); 
        
        
        
        tela.add(lbPrincipal); 
        tela.add(lbTaxaJuros); 
        tela.add(lbPeriodos); 
        tela.add(lbResultado); 
        tela.add(tfPrincipal); 
        tela.add(tfTaxaJuros);
        tela.add(tfPeriodos);
        tela.add(btCalcular); 
        tela.add(lbMontante);
        tela.add(lbPorcento);
        tela.add(lbReais);
        tela.add(lbMes);
        tela.add(btLimpar);
  
        tela.setSize(390, 230); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
} 