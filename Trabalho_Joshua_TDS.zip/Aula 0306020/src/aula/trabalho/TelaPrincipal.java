package aula.trabalho;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.net.URL;
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 
import javax.swing.text.StyleConstants;

public class TelaPrincipal extends javax.swing.JFrame { 

    JFrame tela; 
    JMenuBar mbMenu; 
    
    JMenu mInvestimentoJS; 
    JMenuItem miMonFuturoJS; 
    JMenuItem miDefiniCapital; 
    JMenuItem miDefiniPeriodo; 
    JMenuItem miDefiniTaxaJuros; 
    
    JMenu mInvestimentoJC; 
    JMenuItem miMonFuturoJC; 
    JMenuItem miDefiniCapitalJC; 
    JMenuItem miDefiniPeriodoJC; 
    JMenuItem miDefiniJC;
    
    JMenu mExtras; 
    JMenuItem miAutor; 
    JMenuItem miAjuda; 
    JMenuItem miCalculadora ; 
    
    JLabel lbImagem;
    URL urlImagem;  
        
    public TelaPrincipal()
    {
        tela = new JFrame("Futuro Certo - Seu investimeto aqui acontece!");
        mbMenu = new JMenuBar(); 
        mInvestimentoJS = new JMenu("Investimento JS"); 
        miMonFuturoJS = new JMenuItem("Montante Futuro"); 
        miDefiniCapital = new JMenuItem("Definição do Capital"); 
        miDefiniPeriodo = new JMenuItem("Definição do Período"); 
        miDefiniTaxaJuros = new JMenuItem("Definição da Taxa de Juros"); 
        mInvestimentoJC = new JMenu("Investimento JC"); 
        miMonFuturoJC = new JMenuItem("Montante Futuro"); 
        miDefiniCapitalJC = new JMenuItem("Definição do Capital"); 
        miDefiniPeriodoJC = new JMenuItem("Definição do Período"); 
        miDefiniJC = new JMenuItem ("Definição do Juros Composto");
        mExtras = new JMenu("Extra"); 
        miAutor = new JMenuItem("Autor"); 
        miAjuda = new JMenuItem("Ajuda"); 
        miCalculadora = new JMenuItem("Calculadora"); 
        lbImagem = new JLabel();
        
        lbImagem.setBounds(0, 0, 580, 250);
        urlImagem = getClass().getResource("futuro.jpeg");
        Icon iconImge = new ImageIcon(urlImagem);
        lbImagem.setIcon(iconImge);
        

        mbMenu.add(mInvestimentoJS);    
        mbMenu.add(mInvestimentoJC); 
        mbMenu.add(mExtras); 
        mInvestimentoJS.add(miMonFuturoJS); 
        mInvestimentoJS.add(miDefiniCapital); 
        mInvestimentoJS.add(miDefiniPeriodo);
        mInvestimentoJS.add(miDefiniTaxaJuros);
        mInvestimentoJC.add(miMonFuturoJC); 
        mInvestimentoJC.add(miDefiniCapitalJC);
        mInvestimentoJC.add(miDefiniPeriodoJC);
        mInvestimentoJC.add(miDefiniJC);
        
        mExtras.add(miCalculadora); 
        mExtras.add(miAjuda); 
        mExtras.add(miAutor); 
        
        miMonFuturoJS.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfMontanteSimples telaMJS = new TfMontanteSimples(); 
            } 
        }); 

        miDefiniCapital.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfDefiniCapital telaDFJS = new TfDefiniCapital(); 
            } 
        }); 
        
        miDefiniPeriodo.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfDefiniPeriodo telaDPJS = new TfDefiniPeriodo(); 
            } 
        }); 
        
        miDefiniTaxaJuros.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfTaxaJuros telaDTJS = new TfTaxaJuros(); 
            } 
        }); 
        
        miMonFuturoJC.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfMontanteComposto telaMC= new TfMontanteComposto(); 
            } 
        }); 
        
        miDefiniCapitalJC.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfDefiniCapitalJC telaCJC= new TfDefiniCapitalJC(); 
            } 
        }); 
        
        miDefiniPeriodoJC.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfDefiniPeriodoJC telaCJC= new TfDefiniPeriodoJC(); 
            } 
        }); 
        
        miAutor.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfAutor telaAutor = new TfAutor(); 
            } 
        }); 
        
        miCalculadora.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                Calculadora telaCalc = new Calculadora(); 
                java.awt.EventQueue.invokeLater(new Runnable() 
            {
                public void run() 
                {
                new Calculadora().setVisible(true);
                }
            });
            }
        });
        
        
        miDefiniJC.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfJurosComposto telaDJC = new TfJurosComposto(); 
            } 
        }); 
        
        miAjuda.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                TfAjuda telaAjuda = new TfAjuda(); 
            } 
        }); 

        tela.setResizable(false);
        tela.add(lbImagem);
        tela.setJMenuBar(mbMenu); 
        tela.setSize(550, 310); 
        tela.setDefaultCloseOperation(EXIT_ON_CLOSE); 
        tela.setLayout(null); 
        tela.setVisible(true); 
     
    }   

} 