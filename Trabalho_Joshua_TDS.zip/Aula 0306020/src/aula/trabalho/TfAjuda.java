package aula.trabalho;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.net.URL;
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfAjuda
{ 
    JFrame tela; 
    JLabel lbLinha1, lbLinha2, lbLinha3, lbLinha4, lbLinha5, lbLinha6, lbLinha7, lbLinha8, lbLinha9, lbLinha10, lbLinha11;


    public TfAjuda() 
    { 
        
        tela = new JFrame("Ajuda - O que é Juros?"); 
        lbLinha1 = new JLabel("Juros Composto: Os juros compostos são aqueles nos quais");
        lbLinha1.setBounds(10, 10, 380, 20); 
        
        lbLinha2 = new JLabel("os juros do mês são incorporados ao capital. Com uma taxa ");
        lbLinha2.setBounds(10, 25, 380, 20);
        
        lbLinha3 = new JLabel("assim, o valor cresce muito mais rápido do que com juros");
        lbLinha3.setBounds(10, 40, 380, 20);
        
        lbLinha4 = new JLabel("simples.");
        lbLinha4.setBounds(10, 55, 380, 20);
        
        lbLinha5 = new JLabel("Juros Simples: Os juros simples podem ser entendidos como");
        lbLinha5.setBounds(10, 85, 380, 20);
        
        lbLinha6 = new JLabel("o rendimento de uma aplicação financeira de curto prazo. ");
        lbLinha6.setBounds(10, 100, 380, 20);
        
        lbLinha7 = new JLabel("Para se calcular os juros simples e os juros compostos, é ne-");
        lbLinha7.setBounds(10, 130, 380, 20);
        
        lbLinha8 = new JLabel("cessário valores como: Capital, Montante, Taxa de Juros, Ta- ");
        lbLinha8.setBounds(10, 145, 380, 20);
        
        lbLinha9 = new JLabel("xa Fixa e os Periodos (nesse caso, dado em meses).");
        lbLinha9.setBounds(10, 160, 380, 20);
        
        lbLinha10 = new JLabel("Para mais dúvidas, email para contato:");
        lbLinha10.setBounds(10, 190, 380, 20);
        
        lbLinha11 = new JLabel("desenvolvedor@invista.com");
        lbLinha11.setBounds(10, 205, 380, 20);
        
        tela.add(lbLinha1); 
        tela.add(lbLinha2);
        tela.add(lbLinha3);
        tela.add(lbLinha4);
        tela.add(lbLinha5);
        tela.add(lbLinha6);
        tela.add(lbLinha7);
        tela.add(lbLinha8);
        tela.add(lbLinha9);
        tela.add(lbLinha10);
        tela.add(lbLinha11);

        tela.setSize(390, 300); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
    
    
} 
