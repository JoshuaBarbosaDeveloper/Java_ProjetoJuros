package aula.trabalho;

import java.awt.Color;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfAutor
{ 
    JFrame tela; 
    JLabel lbLinha1, lbLinha2, lbLinha3, lbLinha4, lbLinha5, lbLinha6, lbLinha7, lbLinha8, lbLinha9, lbLinha10, lbLinha11;



    public TfAutor() 
    { 
        
        tela = new JFrame("Sobre e Autor"); 
        lbLinha1 = new JLabel("O aplicativo “MoneyCorrectly – Invista no lugar certo!” foi de-");
        lbLinha1.setBounds(10, 10, 380, 20); 
        
        lbLinha2 = new JLabel("senvolvido por Joshua Barbosa, no período de tempo do dia");
        lbLinha2.setBounds(10, 25, 380, 20);
        
        lbLinha3 = new JLabel("08/06/2020 – 15/06/2020. Teve como patrocínio a ONG “Futu-");
        lbLinha3.setBounds(10, 40, 380, 20);
        
        lbLinha4 = new JLabel("ro Certo”, e tinham o desejo de um aplicativo em Java Swing");
        lbLinha4.setBounds(10, 55, 380, 20);
        
        lbLinha5 = new JLabel("Swing que auxiliasse as pessoas nas suas simulações de in-");
        lbLinha5.setBounds(10, 70, 380, 20);
        
        lbLinha6 = new JLabel("vestimentos.");
        lbLinha6.setBounds(10, 85, 380, 20);
        
        lbLinha7 = new JLabel("Situação de Aprendizagem - Investimentos Financeiros, dado");
        lbLinha7.setBounds(10, 115, 380, 20);
        
        lbLinha8 = new JLabel("pelo Professor e Eng. Hugo Cocus, no curso Técnico em Aná-");
        lbLinha8.setBounds(10, 130, 380, 20);
        
        lbLinha9 = new JLabel("lise e Desenvolvimento de Sistemas.");
        lbLinha9.setBounds(10, 145, 380, 20);
        
        lbLinha10 = new JLabel("Versão do Produto: MoneyCorrectly 1.0");
        lbLinha10.setBounds(10, 175, 380, 20);
        
        lbLinha11 = new JLabel("Java: 13.0.2; Java HotSpot(TM) 64-Bit Server VM 13.0.2+8");
        lbLinha11.setBounds(10, 190, 380, 20);
        
        tela.add(lbLinha1); 
        tela.add(lbLinha2);
        tela.add(lbLinha3);
        tela.add(lbLinha4);
        tela.add(lbLinha5);
        tela.add(lbLinha6);
        tela.add(lbLinha7);
        tela.add(lbLinha8);
        tela.add(lbLinha9);
        tela.add(lbLinha10);
        tela.add(lbLinha11);

        tela.setSize(390, 300); 
        tela.setLayout(null); 
        tela.setVisible(true); 

        
    } 
} 
