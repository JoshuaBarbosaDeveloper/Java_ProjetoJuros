package aula.trabalho;

import java.awt.Color;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfDefiniCapitalJC
{ 
    JFrame tela; 
    JLabel lbValorFuturo, lbTaxaFixa, lbPeriodos, lbResultado, lbMontante, lbPorcento, lbReais, lbMes; 
    JTextField tfValorFuturo, tfTaxaFixa, tfPeriodos; 
    JButton btCalcular, btLimpar; 

    public TfDefiniCapitalJC() 
    {   
        tela = new JFrame("Cálculo do Capital"); 
        lbValorFuturo = new JLabel("Montante: ");
        lbReais = new JLabel("Reais");
        lbTaxaFixa = new JLabel("Taxa Fixa: ");
        lbPorcento = new JLabel("%"); 
        lbPeriodos = new JLabel("Quantidade de Periodos: "); 
        lbMes = new JLabel ("Meses");
        lbMontante = new JLabel("Capital: "); 
        lbResultado = new JLabel("Resultado da Operação"); 
        tfValorFuturo= new JTextField(); 
        tfTaxaFixa = new JTextField(); 
        tfPeriodos = new JTextField();
        btCalcular = new JButton("Calcular"); 
        btLimpar = new JButton("Limpar");

        lbValorFuturo.setBounds(10, 10, 150, 20); 
        lbReais.setBounds(325, 10, 100, 20);
        lbTaxaFixa.setBounds(10, 35, 100, 20);
        lbPorcento.setBounds(325, 35, 100, 20);
        lbPeriodos.setBounds(10, 60, 150, 20); 
        lbMes.setBounds(325, 60, 100, 20);
        lbMontante.setBounds(10, 95, 100, 20); 
        lbResultado.setBounds(170, 95, 149, 20); 
        tfValorFuturo.setBounds(170, 10, 150, 20); 
        tfTaxaFixa.setBounds(170, 35, 150, 20);
        tfPeriodos.setBounds(170, 60, 150, 20);
        btCalcular.setBounds(10, 128, 265, 30); 
        btLimpar.setBounds(281, 128, 82, 30);
        
        lbResultado.setHorizontalAlignment(JLabel.CENTER);
        lbResultado.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbResultado.setOpaque(true); 

        btCalcular.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    
                    Double principal, taxaFixa, periodos, montante, capital; 
                    montante = Double.parseDouble(tfValorFuturo.getText()); 
                    taxaFixa = Double.parseDouble(tfTaxaFixa.getText()); 
                    periodos = Double.parseDouble(tfPeriodos.getText()); 
                    taxaFixa = taxaFixa / 100;
                    capital = montante / (Math.pow((1 + taxaFixa),periodos));
                    lbResultado.setText(String.valueOf(capital) + " Reais"); 

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível realizar o cálculo."); 
                } 
            } 
        }); 
        
        btLimpar.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    tfValorFuturo.setText("");
                    tfTaxaFixa.setText("");
                    tfPeriodos.setText(""); 
                    lbResultado.setText("Resultado da Operação");

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível limpar!"); 
                } 
            } 
        }); 
        
        tela.add(lbValorFuturo); 
        tela.add(lbTaxaFixa); 
        tela.add(lbPeriodos); 
        tela.add(lbResultado); 
        tela.add(tfValorFuturo); 
        tela.add(tfTaxaFixa);
        tela.add(tfPeriodos);
        tela.add(btCalcular); 
        tela.add(lbMontante);
        tela.add(lbPorcento);
        tela.add(lbReais);
        tela.add(lbMes);
        tela.add(btLimpar);
  
        tela.setSize(390, 230); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
} 