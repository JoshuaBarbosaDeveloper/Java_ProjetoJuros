package aula.trabalho;

import java.awt.Color;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfDefiniPeriodo
{ 
    JFrame tela; 
    JLabel lbPrincipal, lbValorFuturo, lbTaxaJuros, lbResultado, lbMontante, lbPorcento, lbReais, lbMes; 
    JTextField tfPrincipal, tfValorFuturo, tfTaxaJuros; 
    JButton btCalcular, btLimpar; 

    public TfDefiniPeriodo() 
    { 
       
        tela = new JFrame("Cálculo do Período"); 
        lbPrincipal = new JLabel("Valor do Montante: ");
        lbReais = new JLabel("Reais");
        lbValorFuturo = new JLabel("Valor Futuro: ");
        lbPorcento = new JLabel("Reais"); 
        lbTaxaJuros = new JLabel("Taxa de Juros: "); 
        lbMes = new JLabel ("%");
        lbMontante = new JLabel("Periodos: "); 
        lbResultado = new JLabel("Resultado da Operação"); 
        tfPrincipal= new JTextField(); 
        tfValorFuturo = new JTextField(); 
        tfTaxaJuros = new JTextField();
        btCalcular = new JButton("Calcular"); 
        btLimpar = new JButton("Limpar");

        lbPrincipal.setBounds(10, 10, 150, 20); 
        lbReais.setBounds(325, 10, 100, 20);
        lbValorFuturo.setBounds(10, 35, 100, 20);
        lbPorcento.setBounds(325, 35, 100, 20);
        lbTaxaJuros.setBounds(10, 60, 150, 20); 
        lbMes.setBounds(325, 60, 100, 20);
        lbMontante.setBounds(10, 95, 100, 20); 
        lbResultado.setBounds(170, 95, 149, 20); 
        tfPrincipal.setBounds(170, 10, 150, 20); 
        tfValorFuturo.setBounds(170, 35, 150, 20);
        tfTaxaJuros.setBounds(170, 60, 150, 20);
        btCalcular.setBounds(10, 128, 265, 30); 
        btLimpar.setBounds(281, 128, 82, 30);
        
        lbResultado.setHorizontalAlignment(JLabel.CENTER);
        lbResultado.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbResultado.setOpaque(true); 

        btCalcular.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    Double taxaJuros, periodos;
                    Double montante, valorFuturo;
                    montante = Double.parseDouble(tfPrincipal.getText()); 
                    taxaJuros = Double.parseDouble(tfTaxaJuros.getText()); 
                    valorFuturo = Double.parseDouble(tfValorFuturo.getText()); 
                    periodos = (valorFuturo - montante) / (montante * taxaJuros / 100); //n = (F - P)/(P.i)
                    lbResultado.setText(String.valueOf(periodos) + " Meses"); 

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível realizar o cálculo."); 
                } 
            } 
        }); 
        
        btLimpar.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    tfPrincipal.setText("");
                    tfTaxaJuros.setText("");
                    tfValorFuturo.setText(""); 
                    lbResultado.setText("Resultado da Operação");

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível limpar!"); 
                } 
            } 
        }); 
        
        tela.add(lbPrincipal); 
        tela.add(lbValorFuturo); 
        tela.add(lbTaxaJuros); 
        tela.add(lbResultado); 
        tela.add(tfPrincipal); 
        tela.add(tfTaxaJuros);
        tela.add(tfValorFuturo);
        tela.add(btCalcular); 
        tela.add(lbMontante);
        tela.add(lbPorcento);
        tela.add(lbReais);
        tela.add(lbMes);
        tela.add(btLimpar);
  
        tela.setSize(390, 230); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
} 