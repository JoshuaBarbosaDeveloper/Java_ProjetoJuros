package aula.trabalho;

import java.awt.Color;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.*; 
import static javax.swing.JFrame.EXIT_ON_CLOSE; 

public class TfTaxaJuros
{ 
    JFrame tela; 
    JLabel lbPrincipal, lbValorFuturo, lbPeriodos, lbResultado, lbMontante, lbPorcento, lbReais, lbMes; 
    JTextField tfPrincipal, tfValorFuturo, tfPeriodos; 
    JButton btCalcular, btLimpar; 

    public TfTaxaJuros() 
    { 
       
        tela = new JFrame("Cálculo da Taxa de Juros"); 
        lbPrincipal = new JLabel("Valor do Montante: ");
        lbReais = new JLabel("Reais");
        lbValorFuturo = new JLabel("Valor Futuro: ");
        lbPorcento = new JLabel("Reais"); 
        lbPeriodos = new JLabel("Periodos: "); 
        lbMes = new JLabel ("Meses");
        lbMontante = new JLabel("Taxa de Juros: "); 
        lbResultado = new JLabel("Resultado da Operação"); 
        tfPrincipal= new JTextField(); 
        tfValorFuturo = new JTextField(); 
        tfPeriodos = new JTextField();
        btCalcular = new JButton("Calcular"); 
        btLimpar = new JButton("Limpar");

        lbPrincipal.setBounds(10, 10, 150, 20); 
        lbReais.setBounds(325, 10, 100, 20);
        lbValorFuturo.setBounds(10, 35, 100, 20);
        lbPorcento.setBounds(325, 35, 100, 20);
        lbPeriodos.setBounds(10, 60, 150, 20); 
        lbMes.setBounds(325, 60, 100, 20);
        lbMontante.setBounds(10, 95, 100, 20); 
        lbResultado.setBounds(170, 95, 149, 20); 
        tfPrincipal.setBounds(170, 10, 150, 20); 
        tfValorFuturo.setBounds(170, 35, 150, 20);
        tfPeriodos.setBounds(170, 60, 150, 20);
        btCalcular.setBounds(10, 128, 265, 30); 
        btLimpar.setBounds(281, 128, 82, 30);
        
        lbResultado.setHorizontalAlignment(JLabel.CENTER);
        lbResultado.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbResultado.setOpaque(true); 

        btCalcular.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    Double taxaJuros, periodos;
                    Double montante, valorFuturo;
                    montante = Double.parseDouble(tfPrincipal.getText()); 
                    periodos = Double.parseDouble(tfPeriodos.getText()); 
                    valorFuturo = Double.parseDouble(tfValorFuturo.getText()); 
                    taxaJuros = (valorFuturo - montante) / (montante * periodos) * 100; //i = (F - P)/(P.n)
                    lbResultado.setText(String.valueOf(taxaJuros) + " %"); 

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível realizar o cálculo."); 
                } 
            } 
        }); 
        
        btLimpar.addActionListener(new ActionListener() 
        { 
            @Override 
            public void actionPerformed(ActionEvent e) 
            { 
                try 
                { 
                    tfPrincipal.setText("");
                    tfPeriodos.setText("");
                    tfValorFuturo.setText(""); 
                    lbResultado.setText("Resultado da Operação");

                } catch(Exception ex) 
                { 
                    JOptionPane.showMessageDialog(tela, "Erro! Não foi possível limpar!"); 
                } 
            } 
        }); 
        
        tela.add(lbPrincipal); 
        tela.add(lbValorFuturo); 
        tela.add(lbPeriodos); 
        tela.add(lbResultado); 
        tela.add(tfPrincipal); 
        tela.add(tfPeriodos);
        tela.add(tfValorFuturo);
        tela.add(btCalcular); 
        tela.add(lbMontante);
        tela.add(lbPorcento);
        tela.add(lbReais);
        tela.add(lbMes);
        tela.add(btLimpar);
  
        tela.setSize(390, 230); 
        tela.setLayout(null); 
        tela.setVisible(true); 

    } 
} 